# FLM Android 11 External Storage Support
It Can Read FLM User Files!!!
(Just Added Permission MANAGE_EXTERNAL_STORAGE lol)
